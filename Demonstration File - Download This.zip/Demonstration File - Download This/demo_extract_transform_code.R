#[--- A Computational Approach for Analysis of Open Data Portal User-Orientation ---]
#[--- Demonstration data extraction and transformation script ---]

# This is a demonstration script to extract and transform metadata
# from the ckan repository for the open data portal for Ireland.

# The script also references data files provided in the project folder
# that have been scraped from the open data portal Ireland by the Screaming Frog web crawler.



#[--- LOAD PACKAGE DEPENDENCIES AND DECLARE HARDCODED VARIABLES ---]

# load package dependencies
# if you do not have these packages installed, please do so before running the script 
library(ckanr)
library(tidyverse)
library(expss)
library(data.table)

# hardcoded country code variable (in this case, for Ireland)
country_code<-"ie"

# declares portal uri
ckanr_setup(url = "https://data.gov.ie")



#[--- MAKE CKAN API REQUESTS ---]

api_result <- c()
i <- 1
step <- 1000

# returns 1,000 data packages per call
# begins at first package
# return 1,000 until all packages are returned
while (TRUE) {
  temp_search <- package_search(q = '*:*', rows = step, start = i)$results
  print(paste0(i, " ", length(temp_search)))
  if (length(temp_search) == 0) break
  api_result <- c(api_result, temp_search)
  i <- i + step
  Sys.sleep(0) # rate limit set to 10 seconds
}



#[--- CREATE A DATA FRAME OF METADATA FOR ALL RESOURCES (DATA FILES) LINKED FROM DATASET PACKAGES ---]

# resource edit function
# takes the nested list object 'package'
# discards null values
# discards list values
# maps and then binds all list items to individual dataframes
f <- function(package) {
  package$resources %>%
    map(~ discard(., is.null)) %>%
    map(~ discard(., is.list)) %>%
    map(as_data_frame) %>% 
    bind_rows()
}

# dataframe of resource data
# takes the object api_result
# invokes function f
# binds all dataframes for list items to single dataframe
# replaces all values that are blank or contain only hypens with NA
r1 <- api_result %>% 
  map(f) %>% 
  bind_rows() %>%
  replace(., .=="",NA)%>%
  replace(., .=="-",NA)



#[--- CREATE A DATA FRAME OF METADATA FOR ALL DATASET PACKAGES ---]

# dataframe of metadata
# takes the object api_result
# discards null values
# discards list values
# maps and then binds all list items to a single dataframe
# replaces all values that are blank or contain only hypens with NA
# assigns dataset package id as the primary key
m1 <- api_result %>% 
  map(~ discard(., is.null)) %>% 
  map(~ discard(., is.list)) %>% 
  map(as_data_frame) %>% 
  bind_rows() %>%
  replace(., .=="",NA)%>%
  replace(., .=="-",NA)%>%
  select(id, everything())



#[--- CREATE WEB CRAWL DATA FRAMES ---]

# dataframe of web crawl data
# read .csv file containing web crawler page level data
# replace all blank values with NA
web_data <- 
  read.csv("web_master_ie.csv", header = TRUE) %>%
  replace(., .=="", "NA")

# dataframe of web crawl data
# read .csv file containing web crawler page level data
# replace all blank values with NA
image_data<-
  read.csv("web_alt_ie.csv", header = TRUE)%>%
  replace(., .=="", "NA")



#[--- METRIC CALCULATIONS ---]



#[--- CATEGORY 1: ORGANISE FOR USE ---]

# create an empty category metric table
organise_for_use <- data.frame(matrix(ncol = 5, nrow = 1))
organise_for_use_column_names <- c("Descriptive_Record", "Preview", "Recommendations", "Ratings", "Keywords")
colnames(organise_for_use) <- organise_for_use_column_names
organise_for_use_row_names <- c(country_code)
rownames(organise_for_use) <- organise_for_use_row_names

# Metric 1a: Descriptive Record
organise_for_use$Descriptive_Record <- sum(!is.na(m1$notes)) / NROW(m1$notes)

# Metric 1b: Dataset Preview
if("datastore_active" %in% names(r1)){
  organise_for_use$Preview <- sum(r1$datastore_active==TRUE) / NROW(r1$datastore_active)
}else{
  organise_for_use$Preview <- 0
}

# Metric 1c: Recommendations
organise_for_use$Recommendations <- NA

# Metric 1d: Ratings
organise_for_use$Ratings <- NA

# Metric 1e: Keywords
organise_for_use$Keywords <- sum(m1$num_tags>0) / NROW(m1$num_tags)

# write 'organise for use' scores to CSV file
write.csv(organise_for_use,file=paste("1.1_",country_code,"_organise_for_use.csv",sep=""))



#[--- CATEGORY 2: PROMOTE USE  ---]

# create an empty category metric table
promote_use <- data.frame(matrix(ncol = 5, nrow = 1))
promote_use_names <- c("Social_Media_Links", "Feedback_Support", "Newsfeed", "Guidance", "Examples")
colnames(promote_use) <- promote_use_names
promote_use_row_names <- c(country_code)
rownames(promote_use) <- promote_use_row_names

# Metric 2a: Social Media Links
promote_use$Social_Media_Links <- sum(web_data$social==1) / NROW(web_data)

# Metric 2b: Feedback and Support
promote_use$Feedback_Support <- m1%>%
  select(contact_name, contact_email, contact_phone)%>%
  filter(.,!is.na(contact_name))%>%
  filter(.,!is.na(contact_email))%>%
  filter(.,!is.na(contact_phone)) %>%
  NROW(.)/NROW(m1)

# Metric 2c: Newsfeed
promote_use$Newsfeed <-web_data %>%
  select(Address)%>%
  filter(.,grepl("\\b\\/rss\\b|\\b\\/atom\\b|\\b\\.rss\\b|\\b\\.atom\\b|\\b\\/feed\\b|\\b\\.feed\\b",Address))%>%
  NROW(.)%>%
  {ifelse(.>0,1,0)}

# Metric 2d: Guidance
promote_use$Guidance <- m1%>%
  select(contact_name, contact_email, contact_phone, notes)%>%
  filter(.,!is.na(contact_name))%>%
  filter(.,!is.na(contact_email))%>%
  filter(.,!is.na(contact_phone)) %>%
  filter(.,!is.na(notes))%>%
  NROW(.)/NROW(m1)

# Metric 2e: Examples
promote_use$Examples <- NA

# write 'promote use' scores to CSV file
write.csv(promote_use,file=paste("1.2_",country_code,"_promote_use.csv",sep=""))



#[--- CATEGORY 3: BE DISCOVERABLE ---]

# create an empty category metric table
be_discoverable <- data.frame(matrix(ncol = 5, nrow = 1))
be_discoverable_names <- c("Publisher_Portal", "Searchable_Datasets", "Searchable_Datasets_w_Synonyms", "Searchable_Datasets_Unavailable",
                           "Updated_Datasets")
colnames(be_discoverable) <- be_discoverable_names
be_discoverable_row_names <- c(country_code)
rownames(be_discoverable) <- be_discoverable_row_names

# Metric 3a: Publisher Portal
be_discoverable$Publisher_Portal <- NA

# Metric 3b: Searchable Datasets
be_discoverable$Searchable_Datasets <- NA

# Metric 3c: Searchable Datasets with Synonyms 
be_discoverable$Searchable_Datasets_w_Synonyms<- NA

# Metric 3d: Search Datasets that are Unavailable
be_discoverable$Searchable_Datasets_Unavailable <- NA

# Metric 3e: Updated Datasets
if("frequency" %in% names(m1)){
metadata_dates<- 
  m1%>%
  select(frequency,metadata_modified)%>%
  subset(.,frequency %in% c("Annual","Daily","Monthly","Quarterly","Weekly"))%>%
  mutate(metadata_modified_date=as.Date(substr(metadata_modified,1,10)),
         current_date=Sys.Date(),
         frequency_categorical=factor(frequency,levels = c("Annual","Daily","Monthly","Quarterly","Weekly"),
                                      labels = c(365,1,31,92,7)),
         frequency_numeric=as.numeric(as.character(frequency_categorical)),
         days_since_modification=current_date-metadata_modified_date,
         overdue_update=ifelse(days_since_modification-frequency_numeric<0,1,0)
         )

be_discoverable$Updated_Datasets<-count_if(1,metadata_dates$overdue_update)/NROW(metadata_dates)
}else{
  be_discoverable$Updated_Datasets<-0
}

# write 'be discoverable' scores to CSV file
write.csv(be_discoverable,file=paste("1.3_", country_code,"_be_discoverable.csv",sep=""))



#[--- CATEGORY 4: PUBLISH METADATA ---]

# create an empty category metric table
publish_metadata <- data.frame(matrix(ncol = 5, nrow = 1))
publish_metadata_names <- c("Metadata_Ignorance", "Scattered_Or_Closed_Metadata", "Open_Metadata_For_Humans", "Open_Reusable_Metadata",
                           "Linked_Open_Metadata")
colnames(publish_metadata) <- publish_metadata_names
publish_metadata_row_names <- c(country_code)
rownames(publish_metadata) <- publish_metadata_row_names

# Metric 4a: Metadata Ignorance
publish_metadata$Metadata_Ignorance <- NA

# Metric 4b: Scattered or Closed Metadata
publish_metadata$Scattered_Or_Closed_Metadata <- NA

# Metric 4c: Open Metadata for Humans
publish_metadata$Open_Metadata_For_Humans <- NA

# Metric 4d: Open Resusable Metadata
publish_metadata$Open_Reusable_Metadata <- NA

# Metric 4e: Linked Open Metadata
publish_metadata$Linked_Open_Metadata <-
  m1%>%
  select(notes, title, contact_name, contact_email, contact_phone, num_tags, owner_org)%>%
  mutate(contact=ifelse(!is.na(contact_name) | !is.na(contact_email) | !is.na(contact_phone),1,NA))%>%
  select(.,-c(contact_name,contact_email,contact_phone))%>%
  mutate(num_tags1=ifelse(num_tags==0,NA,num_tags))%>%
  select(.,-c(num_tags))%>%
  setnames(.,"num_tags1","num_tags")%>%
  select(everything()) %>%
  summarise_all(list(~sum(!is.na(.))))%>%
  rowSums(.)/(NROW(m1)*5)

# write 'publish metadata' scores to CSV file
write.csv(publish_metadata,file=paste("1.4_", country_code,"_publish_metadata.csv",sep=""))



#[--- CATEGORY 5: PROMOTE STANDARDS ---]

# create an empty category metric table
promote_standards <- data.frame(matrix(ncol = 5, nrow = 1))
promote_standards_names <- c("Permanent_Patterned_Discoverable_URI", "Versioning", "Dates_Available_In_Standard_Format", "Metadata_Available_In_Standard_Format",
                            "Metadata_Catalogue_Retrivable_Using_Standard_Protocol")
colnames(promote_standards) <- promote_standards_names
promote_standards_row_names <- c(country_code)
rownames(promote_standards) <- promote_standards_row_names

# Metric 5a: Permanent, patterned, discoverable URI
promote_standards$Permanent_Patterned_Discoverable_URI <-
  r1%>%
  select(url)%>%
  unique(.)%>%
  NROW(.)/NROW(r1)

# Metric 5b: Versioning
if("version" %in% names(m1)){
  promote_standards$Versioning <-
    m1%>%
    select(version)%>%
    filter(!is.na(.))%>%
    NROW(.)/NROW(m1)
} else{
  promote_standards$Versioning <- 0
}

# Metric 5c: Dates available in standard format
promote_standards$Dates_Available_In_Standard_Format <- NA

# Metric 5d: Metadata avialable in standard format
promote_standards$Metadata_Available_In_Standard_Format <- NA

# Metric 5e: Metadata catalogue retrievable using standard protocol
promote_standards$Metadata_Catalogue_Retrivable_Using_Standard_Protocol <- NA

# write 'promote standards' scores to CSV file
write.csv(promote_standards,file=paste("1.5_",country_code,"_promote_standards.csv",sep=""))



#[--- CATEGORY 6: CO-LOCATE DOCUMENTATION ---]

# create an empty category metric table
co_locate_documentation <- data.frame(matrix(ncol = 5, nrow = 1))
co_locate_documentation_names <- c("None", "Found_Separately", "Co_Located", "Linked_To_Dataset", "Linked_To_Specific_Dataset_Points")
colnames(co_locate_documentation) <- co_locate_documentation_names
co_locate_documentation_row_names <- c(country_code)
rownames(co_locate_documentation) <- co_locate_documentation_row_names

# Metric 6a: None
co_locate_documentation$None <-NA

# Metric 6b: Found separately
co_locate_documentation$Found_Separately <- NA


# Metric 6c: Co-located
if("provenance" %in% names(m1)){
  co_locate_documentation$Co_Located <-
    m1%>%
    select(notes,provenance)%>%
    mutate(documentation_present=ifelse(!is.na(notes) & !is.na(provenance),1,NA))%>%
    select(documentation_present)%>%
    count_if(!is.na(.))/NROW(m1) 
} else{
  co_locate_documentation$Co_Located <- 0
}

# Metric 6d: Linked to dataset
co_locate_documentation$Linked_To_Dataset <- NA

# Metric 6e: Linked to specific dataset points
co_locate_documentation$Linked_To_Specific_Dataset_Points <- NA

# write 'co-locate documentation' scores to CSV file
write.csv(co_locate_documentation,file=paste("1.6_",country_code,"_co_locate_documentation.csv",sep=""))



#[--- CATEGORY 7: LINKED DATA ---]

# create an empty category metric table
linked_data <- data.frame(matrix(ncol = 5, nrow = 1))
linked_data_names <- c("On_The_Web", "Machine_Readable", "Non_Proprietary_Format", "RDF", "Unknown")
colnames(linked_data) <- linked_data_names
linked_data_row_names <- c(country_code)
rownames(linked_data) <- linked_data_row_names

# isolate package IDs and license IDs from dataframe 'm1'
# create new dataframe column to identify open and non-open licence datasets
linked_data_m1<-
  m1%>%
  select(id,license_id)%>%
  `colnames<-`(c("package_id", "license_id"))%>%
  mutate(license=case_when(grepl("creativecommons|cc|CC|uk-ogl|other-open|odc-by|dl|geonutz|geoNUTZ|sbb|open|NonCommercialAllowed
                                 |dcat-ap|dl-de|standaarden",license_id)~"open",
                           !grepl("creativecommons|cc|CC|uk-ogl|other-open|odc-by|dl|geonutz|geoNUTZ|sbb|open|NonCommercialAllowed
                                 |dcat-ap|dl-de|standaarden",license_id)~"other"))

# isolate package IDs and data file formats from dataframe 'r1'
linked_data_r1<-
  r1%>%
  select(package_id,format)

# read the five-star data format look-up table from work folder
look<-read.csv("five_star_look_up.csv",header = TRUE)

# merge redacted 'm1' and 'r1' dataframes by package ID
# create new column that applies five-star data format look-up table to file format column 
five_star_categories<-
  merge(linked_data_m1,linked_data_r1,by="package_id")%>%
  select(package_id,license,format)%>%
  mutate(five_star_category=look$five_star_category[match(unlist(.$format),look$format)])

# Metric 7a: On the web
linked_data$On_The_Web<-
  five_star_categories%>%
  subset(.$five_star_category=='on the web' & .$license=="open")%>%
  NROW(.)/NROW(five_star_categories)

# Metric 7b: Machine readable
linked_data$Machine_Readable<-
  five_star_categories%>%
  subset(.$five_star_category=='machine readable' & .$license=="open")%>%
  NROW(.)/NROW(five_star_categories)

# Metric 7c: Non-proprietary format
linked_data$Non_Proprietary_Format<-
  five_star_categories%>%
  subset(.$five_star_category=='non-proprietary format' & .$license=="open")%>%
  NROW(.)/NROW(five_star_categories)

# Metric 7d: RDF standards
linked_data$RDF<-
  five_star_categories%>%
  subset(.$five_star_category=='RDF' & .$license=="open")%>%
  NROW(.)/NROW(five_star_categories)

# Unknown formats
linked_data$Unknown<-
  five_star_categories%>%
  subset(.$five_star_category=='unknown' & .$license=="open")%>%
  NROW(.)/NROW(five_star_categories)

# write 'linked data' scores to CSV file
write.csv(linked_data,file=paste("1.7_",country_code,"_linked_data.csv",sep=""))



#[--- CATEGORY 8: BE MEASURABLE ---]

# create an empty category metric table
be_measurable <- data.frame(matrix(ncol = 4, nrow = 1))
be_measurable_names <- c("No_Analytics", "Site_Analytics", "Use_Analytics", "Impact_Analytics")
colnames(be_measurable) <- be_measurable_names
be_measurable_row_names <- c(country_code)
rownames(be_measurable) <- be_measurable_row_names

# Metric 8b: Site analytics (re-ordering of metrics deliberate) 
be_measurable$Site_Analytics<-
  web_data%>%
  select(analytics)%>%
  subset(.==1)%>%
  NROW(.)/NROW(web_data)

# Metric 8a: No analytics
be_measurable$No_Analytics<-1-be_measurable$Site_Analytics

# Metric 8c: Use analytics
be_measurable$Use_Analytics<-NA

# Metric 8d: Impact analytics
be_measurable$Impact_Analytics<-NA

# write 'be measurable' scores to CSV file
write.csv(be_measurable,file=paste("1.8_",country_code,"_be_measurable.csv",sep=""))



#[--- CATEGORY 9: CO-LOCATE TOOLS ---]

# create an empty category metric table
co_locate_tools <- data.frame(matrix(ncol = 4, nrow = 1))
co_locate_tools_names <- c("No_Tools", "Visualisation_Tools", "Visualisation_And_Collaboration_Tools_Moderated",
                           "Visualisation_And_Collaboration_Tools_Unmoderated")
colnames(co_locate_tools) <- co_locate_tools_names
co_locate_tools_row_names <- c(country_code)
rownames(co_locate_tools) <- co_locate_tools_row_names

# Metric 9a: No tools
co_locate_tools$No_Tools<-NA

# Metric 9b: Visualisation tools
co_locate_tools$Visualisation_Tools<-NA

# Metric 9c: Visualisation and collaboration tools (moderated)
co_locate_tools$Visualisation_And_Collaboration_Tools_Moderated<-NA

# Metric 9d: Visualisation and collaboration tools (unmoderated)
co_locate_tools$Visualisation_And_Collaboration_Tools_Unmoderated<-NA

# write 'co-locate tools' scores to CSV file
write.csv(co_locate_tools,file=paste("1.9_",country_code,"_co_locate_tools.csv",sep=""))



#[--- CATEGORY 10: BE ACCESSIBLE ---]

# create an empty category metric table
be_accessible <- data.frame(matrix(ncol = 5, nrow = 1))
be_accessible_names <- c("Human_And_Machine_Readable_And_Non_Proprietary_Formats", "Different_Formats_For_The_Same_Datasets",
                         "Instructions_Provided", "Multilingual_Support", "Visual_And_Hearing_Impaired_Support")
colnames(be_accessible) <- be_accessible_names
be_accessible_row_names <- c(country_code)
rownames(be_accessible) <- be_accessible_row_names

# Metric 10a: Human and machine-readable non-proprietary formats
be_accessible$Human_And_Machine_Readable_And_Non_Proprietary_Formats<-NA

# Metric 10b: Different formats for the same datasets
be_accessible$Different_Formats_For_The_Same_Datasets<-
  five_star_categories%>%
  select(package_id,format)%>%
  group_by(format,package_id)%>%
  summarise(format_instances_per_package=n())%>%
  mutate(unqiue_format_instance_present=ifelse(format_instances_per_package>0,1,0))%>%
  group_by(package_id)%>%
  summarise(unique_format_instance_per_package=sum(format_instances_per_package))%>%
  filter(.$unique_format_instance_per_package>1)%>%
  NROW(.)/NROW(unique(five_star_categories$package_id))

# Metric 10c: Instructions provided
be_accessible$Instructions_Provided<-NA

# Metric 10d: Multilingual support 
be_accessible$Multilingual_Support<-
  as.data.frame(web_data$lang)%>%
  subset(.!=0)%>%
  unique(.)%>%
  NROW(.)%>%
  {ifelse(.>1,1,0)}

# Metric 10e.i: HTML5 semantic tags present 
be_accessible.HTML5<-
  web_data%>%
  select(html5)%>%
  subset(.!=0)%>%
  NROW(.)/NROW(web_data)

# Metric 10e.ii: H1 and H2 tags non-blank  
be_accessible.headers<-
  web_data%>%
  select(H1_1,H2_1)%>%
  subset(.,!is.na(H1_1) | !is.na(H2_1))%>%
  NROW(.)/NROW((web_data)*2)

# Metric 10e.iii: Title tag non-blank 
be_accessible.title<-
  web_data%>%
  select(Title.1)%>%
  subset(.,!is.na(.))%>%
  NROW(.)/NROW(web_data)

# Metric 10e.iv: ALT text present
be_accessible.ALT<-
  image_data%>%
  select(alt_present)%>%
  subset(.,alt_present==1)%>%
  NROW(.)/NROW(image_data)

# Metric 10e: Visual and hearing support
be_accessible$Visual_And_Hearing_Impaired_Support<-
  sum(be_accessible.ALT,be_accessible.headers,be_accessible.HTML5,be_accessible.title)/4

# write 'be accessible' scores to CSV file
write.csv(be_accessible,file=paste("2.1_",country_code,"_be_accessible.csv",sep=""))